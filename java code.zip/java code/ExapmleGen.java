package utillities;

public class ExapmleGen {

	public static void main(String[] args) {
		
		String sheetName="DataSync";
		int RowNum=50;
		
		for(int i=1;i<RowNum;i++){
		
			System.out.println("|\""+i+"\"|\""+sheetName+"\"|");
			
					
		}
		

	}

}
