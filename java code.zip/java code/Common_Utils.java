package utillities;

import java.awt.AWTException;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.swing.text.Document;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Verify;

import utillities.BaseTestSetup;
import utillities.ScreenshotUtil_old;



/*
 * ieButtonJSClick() -  Method to Click the IE Browser Buttons.
 * screenshot() - Method to capture the screenshot and updated in the word.
 * webElementExistance() - Method to check the existance of the webElements.
 * 
 * 
 * */
public class Common_Utils {
	
		public WebDriver driver;
		public String current_Work_basket;
	  public static int minWaitVal = 2500;
      public static int mediumWaitVal = 6500;
      public static int maxWaitVal = 15000;
      public static final By SELECT=By.xpath("//*[@id='transactionSection']/table[1]/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[2]/td[1]/select");
      public static final By INPUT=By.xpath("//*[@id='transactionSection']/table[1]/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[2]/td[1]/input");
      private static Logger Log = LogManager.getLogger(Common_Utils.class.getName());
      ScreenshotUtil_old screenshot = new ScreenshotUtil_old();
      DataProvider dataprovider = new DataProvider();
      
	public Common_Utils() {
		this.driver = BaseTestSetup.driver;
	}
/* ---------------------------------------------------------------------
    Method Name: ieButtonJSClick
    Description: Method to Click the IE Browser Buttons.
    Author: Karthik & Swathi
------------------------------------------------------------------------*/
	
	public void ieButtonJSClick(By by)  {
	    try {
	    	int bFlag = webElementExistance(by);
	    	if (bFlag == 1)	{
	    		((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].style.height='auto'; arguments[0].style.visibility='visible';", BaseTestSetup.driver.findElement(by));
		        ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].click();", BaseTestSetup.driver.findElement(by));
	    	}else{
	    		
	    		Log.error("Unable to find the element located by : " + by);
	    		 throw new Exception("Unable to find the element located by :  " + by);
	    	}
	        
	    }
	    catch (Exception e) {
	        Log.error("Failed while performing JS click operation for the element located by : " + by);
	        e.printStackTrace();
			
	    }
	}
	
	
	
/* ---------------------------------------------------------------------
    Method Name: clickOnWebElement
    Description: Method to Click the IE Browser Buttons.
    Author: Karthik & Swathi
------------------------------------------------------------------------*/
	
	public void clickOnWebElement(By by)  {
	    try {
	    	int bFlag = webElementExistance(by);
	    	if (bFlag == 1)	{
	    		driver.findElement(by).click();
	    		System.out.println("Clicked on the element located by: " + by);
	    	}else{
	    		
	    		Log.error("Unable to find the element located by : " + by);
	    		 throw new Exception("Unable to find the element located by :  " + by);
	    	}
	        
	    }
	    catch (Exception e) {
	        Log.error("Failed while performing JS click operation for the element located by : " + by);
	        e.printStackTrace();
			
	    }
	}
		
	
/* ---------------------------------------------------------------------
    Method Name: webElementExistance
    Description: Method to check the existance of the webElements.
    Author: Sathish A
------------------------------------------------------------------------*/			
	
public int webElementExistance(By by){
	sleep(minWaitVal);
	List<WebElement> element = BaseTestSetup.driver.findElements(by);
	int bFlag = 0, iTimeout = 0;
	while (bFlag == 0 && iTimeout <= 2){
		if(element.size()!=0){
		
			bFlag = 1;
		}else{
			sleep(minWaitVal);
			iTimeout++;
		}
		
		
	}	
	return bFlag;
	
}	
/* ---------------------------------------------------------------------
Method Name: webElementExistance
Description: Method to check the existance of the webElements.
Author: Sathish A
------------------------------------------------------------------------*/			

public int webElementExistance(By by, int iSync){
List<WebElement> element = BaseTestSetup.driver.findElements(by);
int bFlag = 0, iTimeout = 0;
while (bFlag == 0 && iTimeout <= iSync){
	if(element.size()!=0){
	
		bFlag = 1;
	}else{
		sleep(1000);
		iTimeout++;
	}
	
	
}	
return bFlag;

}	



/* ---------------------------------------------------------------------
Method Name: webElementExistance
Description: Method to check the existance of the webElements.
Author: Sathish A
------------------------------------------------------------------------*/	

//textbox value

public String getTextFromWebObject(By by){
    String stringValue = null;
    
    int bFlag = webElementExistance(by);
    
    if (bFlag == 1)     
    {
    List<WebElement> ele = BaseTestSetup.driver.findElements(by);
    
    
    for(int i =0; i < ele.size(); i++){
           if(ele.get(i).isDisplayed())
                  stringValue = ele.get(i).getText(); 
                  
           }
    }
           else
           {
                  stringValue="########";
           }
                  
    
    return stringValue;

    
}



public String getTextFromWebElement(By by){
	String stringValue = null;
	List<WebElement> ele = BaseTestSetup.driver.findElements(by);
	
	for(int i =0; i < ele.size(); i++){
		if(ele.get(i).isDisplayed()){
			stringValue = ele.get(i).getText(); 
			break;
		}
		
	}
	
		
	
	return stringValue;

	
}
	
// Dropdown value

public String getFirstOptionfromWebObject(By by) {
    String actualResult=null;
    int bFlag = webElementExistance(by);
    if (bFlag == 1)     
           {                                                     
            WebElement ele = BaseTestSetup.driver.findElement(by);
           Select select = new Select(ele);
           WebElement temp = select.getFirstSelectedOption();
           actualResult  = temp.getText();
           //return actualResult;    
            }
    
    else{
                        
           //return actualResult="######";
           
           actualResult="######";

 }
    return actualResult; 
     
}




/* ---------------------------------------------------------------------
    Method Name: screenshot
    Description: Method to capture the screenshot and updated in the word.
    Author: Karthik & Swathi
------------------------------------------------------------------------*/		
	public void screenshot(){
		try {			
		
			GenericWrapper.captureScreen();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
/* ---------------------------------------------------------------------
    Method Name: enterInputText
    Description: Method to enter the input to the webelement.
    Author: Karthik & Swathi
------------------------------------------------------------------------*/		
	public void enterInputText(By by, String data) {
		int bFlag = webElementExistance(by);
		try {
    	if (bFlag == 1)	{
    		if (!data.trim().isEmpty()) {    				   				
    				WebElement ele1 = BaseTestSetup.driver.findElement(by);
    				ele1.sendKeys("");sleep(1000);
    				ele1.clear();    				
    				ele1.sendKeys(data);
    	   	 }
    	}else{
    		Log.error("Unable to find the element located by : " + by);   		 	
			throw new Exception("Unable to find the element located by :  " + by);			
    		
    	}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   	 
	}
/* ---------------------------------------------------------------------
    Method Name: enterInputText_WC
    Description: Method to enter the input to the webelement.
    Author: Karthik & Swathi
------------------------------------------------------------------------*/		
	public void enterInputText_WC(By by, String data) {
		int bFlag = webElementExistance(by);
		try {
    	if (bFlag == 1)	{
    		if (!data.trim().isEmpty()) {    				   				
    				WebElement ele1 = BaseTestSetup.driver.findElement(by);    				
    				ele1.sendKeys(data);
    				//ele1.sendKeys(Keys.ENTER);
    	   	 }
    	}else{
    		Log.error("Unable to find the element located by : " + by);   		 	
			throw new Exception("Unable to find the element located by :  " + by);			
    		
    	}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   	 
	}	
	
/* ---------------------------------------------------------------------
    Method Name: webElementClick
    Description: Method to Click the webelements.
    Author: Sathish A
------------------------------------------------------------------------*/
	
public void webElementClick(By by){
	
	int bFlag = webElementExistance(by);
	try{
		if (bFlag == 1)	{
			WebElement element = BaseTestSetup.driver.findElement(by);
			element.click();
		}
		else{
			Log.error("Unable to find the element located by : " + by);
			 	throw new Exception("Unable to find the element located by :  " + by);
			
		}
	}
	catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	
}

/* ---------------------------------------------------------------------
Method Name: Switch_To_Frame
Description: Method to wait for given input time.
Author: Sheefa
------------------------------------------------------------------------*/

public void Switch_To_Frame(By frm){
       try{
             WebElement wbFrame=BaseTestSetup.driver.findElement(frm);
           BaseTestSetup.driver.switchTo().frame(wbFrame);
       }
       catch(NoSuchFrameException e){
             System.out.println("There is no frame present here"+e.getMessage());
       }
       
}

public void Switch_To_Default(){
	
	BaseTestSetup.driver.switchTo().defaultContent();
	
}


/* ---------------------------------------------------------------------
Method Name: sleep
Description: Method to wait for given input time.
Author: Karthik & Swathi
------------------------------------------------------------------------*/	
public void sleep(int time) {
	try {
		Thread.sleep(time);
	} catch (InterruptedException e) {
		
	}
}	

/* ---------------------------------------------------------------------
Method Name: actionMouseDClick
Description: Method to click the webelement using Action class.
Author: Karthik & Swathi
------------------------------------------------------------------------*/
public void actionMouseDClick(By by) {
	Actions action = new Actions(driver);
	sleep(2000);
	action.moveToElement(driver.findElement(by)).build().perform();
	driver.findElement(by).click();
}

/* ---------------------------------------------------------------------
Method Name: selectDropDownByText
Description: Method to select the text from the dropdown.
Author: Karthik & Swathi
------------------------------------------------------------------------*/
public void selectDropDownByText(By by, String data) throws Exception {
	int bFlag = webElementExistance(by);
	try{
		if (bFlag == 1)	{
			if (!data.trim().isEmpty()) {
				WebElement element = BaseTestSetup.driver.findElement(by);
				element.sendKeys("");
				Select select = new Select(element);
				select.selectByVisibleText(data);		        
		        }
		    }	else{
			Log.error("Unable to find the element located by : " + by);
			 	throw new Exception("Unable to find the element located by :  " + by);
		    }
	}
	catch (Exception e) {
		// TODO: handle exception
		throw new Exception("Error while login please refer above exception"+" :"+e.getMessage());
	}
	
	
	}
/* ---------------------------------------------------------------------
Method Name: waitForElement
Description: Method to wait for the elements
Author: Karthik & Swathi
------------------------------------------------------------------------*/	
	   
public void waitForElement(By locator) throws Exception {
    try {
        BaseTestSetup.wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(locator));
        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(locator));
        Log.debug("Waiting for element" + locator);
    }
    catch (Exception e) {
        Log.error("Error while waiting for element and the error message is " + e.getMessage());
        throw new Exception("Error while Clicking the webelement identified by " + locator + e.getMessage());
    }
}

/* ---------------------------------------------------------------------
Method Name: enterbyRobot
Description: Method to press the Enter key.
Author: Karthik & Swathi
------------------------------------------------------------------------*/	
public void enterbyRobot()
{
	try {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	} catch (AWTException e) {
	}
	sleep(2000);
}
/* ---------------------------------------------------------------------
Method Name: mouseHoverClick
Description: Method to mouse hover to webelement and click on another webelement
Author: Karthik & Swathi
------------------------------------------------------------------------*/	
public void mouseHoverClick(By source ,By Destination ){

	BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(source));
    ((JavascriptExecutor) BaseTestSetup.driver).executeScript("window.scrollTo(0," + BaseTestSetup.driver.findElement(source).getLocation().y + ")");
       //String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject){ arguments[0].fireEvent('onmouseover');}";
    String onClickScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('click',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject){ arguments[0].fireEvent('onclick');}";
    WebElement sub_Men =  BaseTestSetup.driver.findElement(Destination);
    ((JavascriptExecutor) BaseTestSetup.driver).executeScript(onClickScript,sub_Men);
//     BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(2));
     sleep(mediumWaitVal);
}

/* ---------------------------------------------------------------------
Method Name: mouseHoverClick
Description: Method to mouse hover to webelement and click on another webelement
Author: Karthik & Swathi
------------------------------------------------------------------------*/	
public void mouseHoverClick_tab(By source ,By Destination ){

	BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(source));
    ((JavascriptExecutor) BaseTestSetup.driver).executeScript("window.scrollTo(0," + BaseTestSetup.driver.findElement(source).getLocation().y + ")");
       //String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject){ arguments[0].fireEvent('onmouseover');}";
    String onClickScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('click',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject){ arguments[0].fireEvent('onclick');}";
    WebElement sub_Men =  BaseTestSetup.driver.findElement(Destination);
    ((JavascriptExecutor) BaseTestSetup.driver).executeScript(onClickScript,sub_Men);
//     BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(2));
     sleep(mediumWaitVal);
}



/* ---------------------------------------------------------------------
Method Name: isWebElementPresent
Description: Method to mouse hover to webelement and click on another webelement
Author: Sheefa
------------------------------------------------------------------------*/	
public Boolean isWebElementPresent(By by){
    sleep(minWaitVal);
    Boolean presence;
    try{
          presence=BaseTestSetup.driver.findElement(by).isEnabled();
    }
    catch(NoSuchElementException e){
          presence=false;
    }
    return  presence;
}

/* ---------------------------------------------------------------------
Method Name: getTitleOfWebPage
Description: Method to mouse hover to webelement and click on another webelement
Author: Sheefa
------------------------------------------------------------------------*/	
public String getTitleOfWebPage(){
    String title = null;
    try{
           title= BaseTestSetup.driver.getTitle();
    }
    catch(Exception e){
           System.out.println("Not able to fectch the title"+e.getMessage());
    }
    return title;
}

/* ---------------------------------------------------------------------
Method Name: getText_AcceptAlert
Description: Method to mouse hover to webelement and click on another webelement
Author: Sathish A
------------------------------------------------------------------------*/
	public String getText_AcceptAlert(){
		Alert alert = BaseTestSetup.driver.switchTo().alert();
		String sTempValue = alert.getText();
		alert.accept();
		return sTempValue;
	}
/* ---------------------------------------------------------------------
	Method Name: isAlertPresent
	Description: Method to mouse hover to webelement and click on another webelement
	Author: Sathish A
------------------------------------------------------------------------*/
		public boolean  isAlertPresent(){
			try 
		    { 
		        BaseTestSetup.driver.switchTo().alert(); 
		        return true; 
		    }   // try 
		    catch (NoAlertPresentException Ex) 
		    { 
		        return false; 
		    }   
		}

		/* ---------------------------------------------------------------------
		Method Name: isWebElementDispalyed
		Description: Method to mouse hover to webelement and click on another webelement
		Author: Sheefa
		------------------------------------------------------------------------*/   
		public Boolean isWebElementDisplayed(By by){
		    sleep(minWaitVal);
		    Boolean presence;
		    try{
		          presence=BaseTestSetup.driver.findElement(by).isDisplayed();
		    }
		    catch(NoSuchElementException e){
		       System.out.println("WebElement is not displyed "+e.getMessage());
		          presence=false;
		    }
		    return  presence;
		}
		
/* ---------------------------------------------------------------------
		Method Name: verifyText_SoftAssert
		Description: Method to mouse hover to webelement and click on another webelement
		Author: Sathish A
------------------------------------------------------------------------*/	
		public void verifyText_Select_SoftAssert(By by, String expectedResult) throws Exception{
			boolean result = false;
						
			
	        if(!expectedResult.isEmpty() ){
			int bFlag = webElementExistance(by);
			try{
				if (bFlag == 1)	{
					WebElement ele = BaseTestSetup.driver.findElement(by);
					Select select = new Select(ele);
					WebElement temp = select.getFirstSelectedOption();
					String actualResult = temp.getText();					
					
					if (actualResult.equalsIgnoreCase(expectedResult)){
						Verify.verify(true);
						Log.info( actualResult + " actual result is matches with Expected Result : " + expectedResult);
						System.out.println( actualResult + "actual result is matches with Expected Result : " + expectedResult);
						result = true;
					}else{
						Verify.verify(false);
						Log.info( actualResult + " actual result is mismatch with Expected Result : " + expectedResult);
						System.out.println( actualResult + "actual result is mismatch with Expected Result : " + expectedResult);
						result = true;
					}				
					
				        
				    }else{
					Log.error("Unable to find the element located by : " + by);
					 	throw new Exception("Unable to find the element located by :  " + by);
				    }
			}
			catch (Exception e) {
				// TODO: handle exception
				throw new Exception("Error while login please refer above exception"+" :"+e.getMessage());
			}
			
			
	        }
			
			
			
			
		}

/* ---------------------------------------------------------------------
		Method Name: verifyText_SoftAssert
		Description: Method to mouse hover to webelement and click on another webelement
		Author: Sathish A
------------------------------------------------------------------------*/	
		public void verifyText_SoftAssert(By by, String expectedResult) throws Exception{
			boolean result = false;
			
	        if(!expectedResult.isEmpty() ){
			int bFlag = webElementExistance(by);
			try{
				if (bFlag == 1)	{
					String actualResult ;					
					if (BaseTestSetup.driver.findElement(by).getText().equals("")){
						actualResult = BaseTestSetup.driver.findElement(by).getAttribute("value");
					}else{
						actualResult = BaseTestSetup.driver.findElement(by).getText();
					}
					
					
					if (actualResult.equalsIgnoreCase(expectedResult)){
						Verify.verify(true);
						Log.info( actualResult + " actual result is matches with Expected Result : " + expectedResult);
						System.out.println( actualResult + " actual result is matches with Expected Result : " + expectedResult);
						result = true;
					}else{
						Verify.verify(false);
						Log.info( actualResult + " actual result is mismatch with Expected Result : " + expectedResult);
						System.out.println( actualResult + " actual result is mismatch with Expected Result : " + expectedResult);
						result = true;
					}				
					
				        
				    }else{
					Log.error("Unable to find the element located by : " + by);
					 	
				    }
			}
			catch (Exception e) {
				// TODO: handle exception
				throw new Exception("Error while login please refer above exception"+" :"+e.getMessage());
			}
			
			
	        }
			
			
			
			
		}
		

public void verifyText_SoftAssert_Value(By by, String expectedResult) throws Exception{
                           boolean result = false;
                           System.out.println(expectedResult);
                      if(!expectedResult.isEmpty()){
                           int bFlag = webElementExistance(by);
                           try{
                                  if (bFlag == 1)     {
                                         String actualResult = BaseTestSetup.driver.findElement(by).getAttribute("value");                                  
                                         
                                         expectedResult = expectedResult.toString().trim();
                                         actualResult = actualResult.toString().trim();
                                         System.out.println("ActualResult : " + actualResult);
                                         
                                         if (actualResult.equalsIgnoreCase(expectedResult)){
                                                Verify.verify(true);
                                                Log.info( actualResult + "actual result is match with Expected Result : " + expectedResult);
                                                result = true;
                                         }else{
                                                Verify.verify(false);
                                                Log.info( actualResult + "actual result is mismatch with Expected Result : " + expectedResult);
                                                result = true;
                                         }                          
                                         
                                          
                                      }else{
                                         Log.error("Unable to find the element located by : " + by);
                                               throw new Exception("Unable to find the element located by :  " + by);
                                      }
                           }
                           catch (Exception e) {
                                  // TODO: handle exception
                                  throw new Exception("Error while login please refer above exception"+" :"+e.getMessage());
                           }
                           
                           
                      }
                     
}

/* ---------------------------------------------------------------------
Method Name: verifyText_DataExist
Description: Method to mouse hover to webelement and click on another webelement
Author: Sathish A
------------------------------------------------------------------------*/     
public boolean verifyText_DataExist_Value(By by) throws Exception{
       boolean result = false;
       int bFlag = webElementExistance(by);
       try{
              if (bFlag == 1)     {
                     String actualResult = BaseTestSetup.driver.findElement(by).getAttribute("value");                                  
                     
                     if (!actualResult.equalsIgnoreCase("")){
                           Verify.verify(true);
                           Log.info( actualResult + "actual result is match with Expected Result");
                           result = true;
                     }else{
                           Verify.verify(false);
                           Log.info( actualResult + "actual result is mismatch with Expected Result : ");
                           result = true;
                     }                          
                     
                      
                  }else{
                     Log.error("Unable to find the element located by : " + by);
                           throw new Exception("Unable to find the element located by :  " + by);
                  }
       }
       catch (Exception e) {
              // TODO: handle exception
              throw new Exception("Error while login please refer above exception"+" :"+e.getMessage());
       }
       
       
       
       
       return result;
       
       
}      

/* ---------------------------------------------------------------------
		Method Name: verifyText_DataExist
		Description: Method to mouse hover to webelement and click on another webelement
		Author: Sathish A
------------------------------------------------------------------------*/	
		public boolean verifyText_DataExist(By by) throws Exception{
			boolean result = false;
			int bFlag = webElementExistance(by);
			try{
				if (bFlag == 1)	{
										
					String actualResult ;					
					if (BaseTestSetup.driver.findElement(by).getText().equals("")){
						actualResult = BaseTestSetup.driver.findElement(by).getAttribute("value");
					}else{
						actualResult = BaseTestSetup.driver.findElement(by).getText();
					}
					if (!actualResult.equalsIgnoreCase("")){
						Verify.verify(true);
						Log.info( actualResult + " actual result is matches with Expected Result");
						result = true;
					}else{
						Verify.verify(false);
						Log.info( actualResult + " actual result is mismatch with Expected Result : ");
						result = true;
					}				
					
				        
				    }else{
					Log.error("Unable to find the element located by : " + by);
					 	throw new Exception("Unable to find the element located by :  " + by);
				    }
			}
			catch (Exception e) {
				// TODO: handle exception
				throw new Exception("Error while login please refer above exception"+" :"+e.getMessage());
			}
			
			
			
			
			return result;
			
			
		}	
		
/* ---------------------------------------------------------------------
		Method Name: verifyText_DataExist
		Description: Method to mouse hover to webelement and click on another webelement
		Author: Sathish A
------------------------------------------------------------------------*/	
		public void webelement_CheckBoxClick(By by){
			int bFlag = 0;
			bFlag = webElementExistance(by);
			if(bFlag == 1){
				WebElement element = BaseTestSetup.driver.findElement(by);
				if (!element.isSelected()){
					element.click();
					Log.info("Successfully clicked the WebElement "+ by);
					System.out.println("Successfully clicked the WebElement "+ by);
				}else{
					Log.info("WebElement already selected "+ by);
					System.out.println("WebElement already selected "+ by);
				}
			}
			
		}
		
		
public void mouseMove(By by){
	 WebElement element = BaseTestSetup.driver.findElement(by);
     Actions action = new Actions(BaseTestSetup.driver);
     action.moveToElement(element);
     
     action.moveToElement(element).perform();
}
		


public List<String> getAllTagName(By by){
	List<String> listTagName = new ArrayList<>();
	List<WebElement> element = BaseTestSetup.driver.findElements(by);
	for (int i = 0 ; i < element.size(); i++){
		listTagName.add(element.get(i).getAttribute("tagName"));
	}
	
	return listTagName;
}




public void verifyInterger(By by, int expectedResult) throws Exception{
	boolean result = false;
	int bFlag = webElementExistance(by);
	try{
		if (bFlag == 1)	{
								
			String actualResult ;					
			if (BaseTestSetup.driver.findElement(by).getText().equals("")){
				actualResult = BaseTestSetup.driver.findElement(by).getAttribute("value");
			}else{
				actualResult = BaseTestSetup.driver.findElement(by).getText();
			}
			
			int actualValue= Integer.parseInt(actualResult);
			if (actualValue == expectedResult){
				Verify.verify(true);
				Log.info( actualResult + " actual result is matches with Expected Result");
				result = true;
			}else{
				Verify.verify(false);
				Log.info( actualResult + " actual result is mismatch with Expected Result : ");
				result = true;
			}				
			
		        
		    }else{
			Log.error("Unable to find the element located by : " + by);
			 	throw new Exception("Unable to find the element located by :  " + by);
		    }
	}
	catch (Exception e) {
		// TODO: handle exception
		throw new Exception("Error while login please refer above exception"+" :"+e.getMessage());
	}
	
}
		
		
	public boolean webElement_isSelected(By by){
		WebElement element = BaseTestSetup.driver.findElement(by);
		return element.isSelected();
		
	}
	public void click(By by) {
        actionClick(by);
        sleep(minWaitVal);
     }
	
   public void clickAndWait(By by) {
   actionClick(by);
   sleep(maxWaitVal);
     }
   
   public void webDriverwait(By by){
	   BaseTestSetup.wait.until(ExpectedConditions.visibilityOfElementLocated(by));
   }

   

    public void selectDropDownByValue(By by, String data) {
     if (!data.trim().isEmpty()) {
        actionClick(by);
        selectDropdownByVal(SELECT, data);
        sleep(minWaitVal);}
     }
    
    public void compareVal(int rowNum, String actual, String[] expected, String FieldName){
    	Compare:
    	for(int i = rowNum; i<=expected.length; i++){
    		try{
    		if(expected[i].trim()!=null)
    		if(expected[i].equalsIgnoreCase(actual)){
    		System.out.println(FieldName +" Value "+ "'"+expected[i] +"'"+ " is verified");	 
    		break Compare;
    		}
    		}catch(java.lang.ArrayIndexOutOfBoundsException e){
    			}
    	}
    }
    

/*
     public void selectDropDownByInd(By by, String data) {
     if (!data.trim().isEmpty()) {
        actionClick(by);
        selectDropdownByIndex(SELECT, data);
        sleep(minWaitVal);}
     }*/

    

/*	public void enterInputDateMonthYear(By by, String data) {
	if (!data.trim().isEmpty()) {
	actionClick(by);
//	enterDateMonthYear(data);
	sleep(mediumWaitVal);
}
}*/
	/* public void enterDateMonthYear(String value) {
         System.out.println(value);
         WebElement inputField = driver.findElement(PrescreenWithoutDoc_obj.INPUT);
         sleep(minWaitVal);
         inputField.clear();
         String[] date = value.split("/");
         inputField.sendKeys(date[0].length() > 1 ? date[0] : "0" + date[0]);
         sleep(100);
         inputField.sendKeys(date[1].length() > 1 ? date[1] : "0" + date[1]);
         sleep(100);
         inputField.sendKeys(date[2]);
         sleep(100);
         inputField.sendKeys(Keys.ENTER);
         sleep(mediumWaitVal);
}*/
	public void selectDropdown(By by, String data) {
		sleep(2000);
		if(!data.trim().isEmpty()){
		WebElement ele = driver.findElement(by);
		ele.sendKeys("");
		Select a = new Select(ele);
		a.selectByVisibleText(data);
		}
	}
	
	public void selectElementByName(By by, String Name) throws Exception
	{
		try {
            Select selectitem = new Select(BaseTestSetup.driver.findElement(by));
            selectitem.selectByVisibleText(Name);  
        }
        catch (Exception e) {
            throw new Exception("Error while selecting the option" + Name + " in the Drop down" + e.getMessage());
        }
	}
	
	public void enterInput(By by, String data) throws Exception
	{
		//click(by);
		
		WebElement ele1 = BaseTestSetup.driver.findElement(by);
		ele1.click();
		ele1.sendKeys(data);
		sleep(2000);
	}
	
	public void selectDropdownByVal(By by, String data) {
		sleep(2000);
		WebElement ele = driver.findElement(by);
		ele.click();
		Select a = new Select(ele);
		a.selectByValue(data);
		ele.sendKeys("", Keys.ENTER);
	}

	public void inputText(By by, String data) {
		sleep(1500);
		if(!data.trim().isEmpty()){
		WebElement ele1 = driver.findElement(by);
		ele1.sendKeys("");sleep(500);
		ele1.clear();
		ele1.sendKeys(data);
		}
	}

	public WebElement webDriverWait(By by) {
		WebDriverWait wait = new WebDriverWait(driver, 60);
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(by)));
		return element;
	}
	
//Get attribute value
	
	public String getAttributeFromWebObject(By by)
	{
	       String stringValue = null;
	       int bFlag = webElementExistance(by);
	       
	       if (bFlag == 1)     
	       { 
	       
	              List<WebElement> ele = BaseTestSetup.driver.findElements(by);
	           for(int i =0; i < ele.size(); i++)
	               {
	                     if(ele.get(i).isDisplayed())
	                     
	                     stringValue = ele.get(i).getAttribute("value");
	              
	                 }  
	       
	       }
	       
	       else
	       {
	              
	              return stringValue="########";
	                     
	       }
	       return stringValue;
	       
	       
	       
	}


	
	public Common_Utils selectElementByNameMethod(By locator, String data) throws Exception {

        try {

            Select selectitem = new Select(BaseTestSetup.driver.findElement(locator));
            selectitem.selectByVisibleText(data);
            Thread.sleep(2000);
            Log.debug("Option " + data + " Selected in the dropdown");
        }
        catch (Exception e) {
            Log.error("Option " + data + " not selected in the dropdown :" + e.getMessage());
            throw new Exception("Error while selecting the option" + data + " in the Drop down" + e.getMessage());
        }
    
    return this;
}
	
	
	
	
	public void compareByText(By by, String Actual,String FieldString){
		if(!(Actual).trim().isEmpty()){
			System.out.println(BaseTestSetup.driver.findElement(by).getText().trim());
			System.out.println(Actual);
		if(BaseTestSetup.driver.findElement(by).getText().equalsIgnoreCase(Actual)){
			System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(by).getText()+ ", The Actual Value : "+Actual + ". And it matches");
			}
			sleep(1000);}
		}
	
	public void actionDoubleClick(By by) {
		Actions action = new Actions(driver);
		sleep(2000);
		action.doubleClick(driver.findElement(by)).build().perform();
	}
	
	
	

	public void actionClick(By by)  {
		int bFlag = webElementExistance(by);
		if (bFlag == 1){
			sleep(1000);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(by));
		}else{
			Log.error("Unable to find the element located by : " + by);
		 	
		}
		
	}
	
	public void scrollUpVertical(WebElement ele){
		sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("arguments[0].scrollIntoView();", ele);
	}

	public void acceptAlert() {
		Alert alert = driver.switchTo().alert();
		alert.accept();
	}

	public void dismissAlert() {
		Alert alert = driver.switchTo().alert();
		alert.dismiss();
	}

	
	
	
	
	public static void robotCopyPaste(String test) throws InterruptedException, AWTException{
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Clipboard clipboard = toolkit.getSystemClipboard();
		StringSelection strSel = new StringSelection(test);
		clipboard.setContents(strSel, null);
		Thread.sleep(1000);
		Robot robot = new Robot();
		Thread.sleep(1000);
   	   robot.keyPress(KeyEvent.VK_CONTROL);
   	   robot.keyPress(KeyEvent.VK_V);
   	   robot.keyRelease(KeyEvent.VK_V);
   	   robot.keyRelease(KeyEvent.VK_CONTROL); 	
   	Thread.sleep(1000);
	}	
	
	public void waitForTextPresent(By by, String expText) {
		int maxTimeOut = 500;
		int count = 0;
		boolean elementExists = false;

		while (!elementExists && count < maxTimeOut) {
			try {
				if (driver.findElement(by).getText().trim().equalsIgnoreCase(expText)) {
					elementExists = true;
					System.out.println("Queue is validated");
					break;
				} else {
					Thread.sleep(10000);
					System.out.println("Expected Current Step is not available, Search again");
					count = count + 10;
				}
			} catch (NoSuchElementException | InterruptedException ex) {
			}
		}
	}
	
	public void waitForTextToLoad(By by, String expText) {
		int maxTimeOut = 250;
		int count = 0;
		boolean elementExists = false;
		Text:
		while (!elementExists && count < maxTimeOut) {
			try{
				System.out.println(driver.findElement(by).getText());
				if (driver.findElement(by).getText().trim().equalsIgnoreCase(expText)||
						driver.findElement(by).getAttribute("value").trim().equalsIgnoreCase(expText)) {
					elementExists = true;
					System.out.println("Text validated : "+expText);
					break Text;
				}
			}catch (Exception e) {
				//System.out.println(e);
			}
					//sleep(minWaitVal);
					System.out.println("Text is not available searching again");
					count = count + 10;
			}
	}
	
/*	public String queueLastStepValidation(String queueValidate, String referenceID) {
		waitForTextPresent(By.xpath("//td[text()='"+referenceID+"']/../td[7]"), queueValidate);
		return driver.findElement(By.xpath("//td[text()='"+referenceID+"']/../td[7]")).getText().trim();
	}*/
	
	public void winHandle(){
		 try{ String winHandleBefore = driver.getWindowHandle();
		 for(String winHandle : driver.getWindowHandles()){
		 System.out.println(winHandleBefore); System.out.println(winHandle);
		 driver.switchTo().window(winHandle); } 
		 driver.findElement(By.xpath("//button[@class='saveBtn']")).click();
		 driver.switchTo().window(winHandleBefore); } 
		 catch (Exception e) {
		 System.out.println("RefID is not locked by any"); }
	}
	
	
	public void selectDropdownByValue(By by, String data) {
		sleep(2000);
		WebElement ele = driver.findElement(by);
		ele.sendKeys("");
		Select a = new Select(ele);
		sleep(1000);
		
		a.selectByValue(data);
		ele.sendKeys("", Keys.ENTER);
		}

/*public void selectDropdownByIndex(By by, String data){
		
		WebElement dropdown = driver.findElement(by);
		List<WebElement> options = dropdown.findElements(By.tagName("option"));
		Iterator<WebElement> iter = options.iterator();
		 int ind = 0;
		 String ExpectedListVal = data;
		 
		 while(iter.hasNext()){
			 WebElement textval = iter.next();
			 String ActualListVal = textval.getText();
			System.out.println(textval.getText());
			 
			 if (ActualListVal.contains(ExpectedListVal)){
				 
					WebElement ele = driver.findElement(FrontendDataEntryMaker_obj.SELECT);
					ele.sendKeys("");
					Select a = new Select(ele);					
					a.selectByIndex(ind);
					System.out.println("Index identified is : " + ind);
					getListValues(by);
					ele.sendKeys("", Keys.ENTER);
				    break;
			 }
			 ind = ind+1;
	     };
	}
*/
	
	

/*public void getXpaths() {
	int size = driver.findElements(By.xpath("//table[@id='data-table']/tbody/tr")).size();
	for(int j=0; j<size; j++) {
		WebElement ele = driver.findElement(By.xpath("//table[@id='data-table']/tbody/tr["+(j+1)+"]"));
		if(ele.getAttribute("aria-hidden")== null || !ele.getAttribute("aria-hidden").equals("true")) {
			if(!ele.getAttribute("class").equals("thead")) {
					System.out.print("public static final By "+getFieldName(driver.findElement(By.xpath("//table[@id='data-table']/tbody/tr["+(j+1)+"]/td[1]")).getAttribute("innerHTML"))); 
					System.out.println(" = By.xpath(\""+getLocator(driver.findElement(By.xpath("//table[@id='data-table']/tbody/tr["+(j+1)+"]/td[2]")).getAttribute("innerHTML"))+"\");"); 
					//System.out.println(" - "+getLocatorType(driver.findElement(By.xpath("//table[@id='data-table']/tbody/tr["+(j+1)+"]/td[2]")).getAttribute("innerHTML"))); 
			}
		}
	}
}*/

/*public String getFieldName(String name) {
	if(name.contains("<sup>")) {
		name = name.replace((name.substring(name.indexOf("<sup>"), (name.indexOf("</sup>") + 6))), ""); 
	}
	name = name.substring(name.indexOf(">") + 1, name.lastIndexOf("<"));
	return name.toUpperCase().replaceAll(" ", "_").trim();
}

public String getLocator(String locator) {
	locator = locator.substring(locator.indexOf("title="), (locator.indexOf("\" ", locator.indexOf("title=")) + 1));
	return "//div[@" + locator.replaceAll("\"", "'").trim() + "]";
}

public String getLocatorType(String locator) {
	if (locator.contains("input") || locator.contains("Input") || locator.contains("INPUT")) {
		return "input";
	} else if (locator.contains("select") || locator.contains("Select") || locator.contains("SELECT")) {
		return "select";
	}
	return null;
}*/


/*public String captureScreen() {
    String path;
    try {
 
        File source = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        path = "C:/screenshot/" + source.getName();
        FileUtils.copyFile(source, new File(path)); 
    }
    catch(IOException e) {
        path = "Failed to capture screenshot: " + e.getMessage();
    }
    return path;
}

*/

/* public static void captureScreenShot() throws Exception {
	 XWPFDocument docx = new XWPFDocument();
     XWPFRun run = docx.createParagraph().createRun();
        String screenshot_name = System.currentTimeMillis() + ".png";
        BufferedImage image = new Robot()
                .createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
        File file = new File("C:/screenshot/" + screenshot_name);
        ImageIO.write(image, "png", file);
         InputStream pic = new FileInputStream("C:/screenshot/" + screenshot_name);
        run.addBreak();
        run.addPicture(pic, XWPFDocument.PICTURE_TYPE_PNG, screenshot_name, Units.toEMU(350), Units.toEMU(350));
        FileOutputStream out = new FileOutputStream("C:/screenshot/doc1.docx");
        TimeUnit.SECONDS.sleep(1);
        docx.write(out);
        docx.close();
        out.close();
       // file.delete();
    }*/
 /*public void screenshot(){
 try {
     XWPFDocument docx = new XWPFDocument();
     XWPFRun run = docx.createParagraph().createRun();
     FileOutputStream out = new FileOutputStream("C:/screenshot/doc1.docx");
         captureScreenShot(docx, run, out);
         TimeUnit.SECONDS.sleep(1);
       docx.write(out);
 } catch (Exception e) {
     e.printStackTrace();
 }
}*/


public void screenShot(String ScreenName,String ScenarioName) throws IOException, InterruptedException
{
	String filePath="C:/screenshot";
	String foldername=ScenarioName+timestamp();
    String finalPath=filePath + foldername;
    File f1=new File(finalPath);
    if (!f1.exists())
    {	
    	System.out.print("No Folder");
    	f1.mkdir();
        System.out.print("Folder created");
    }
    File scr=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
    File dest= new File(finalPath+"/screenshot_"+ScreenName+"_" + TimeVal()+".png");
    FileUtils.copyFile(scr, dest);
}



public String timestamp() {
    return new SimpleDateFormat("yyyy-MM-dd").format(new Date());
}

public String TimeVal() {
    return new SimpleDateFormat("hh-mm-ss").format(new Date());
}

public void getListValues(By by/*, String columnname, String rowname*/ ){
    String dropvalues ="";
    
    WebElement ele = driver.findElement(by);
    Select dropDown = new Select(ele);
    System.out.println("entered into getlistvalues");
    List<WebElement> e = dropDown.getOptions();
    int itemCount = e.size();

    for(int l = 0; l < itemCount; l++)
    {
        System.out.println(e.get(l).getText());
        String listVal = e.get(l).getText();
        // String temp=listVal;
        dropvalues= dropvalues+", "+listVal;
       
    }
//  System.out.println(dropvalues+": list of values in dropdown"  );
    //dataprovider.insertExcelData(rowname, columnname, ICDDrefNo);
}
public void triggerOnClick(WebElement element) throws Exception{
	try{
	String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject){ arguments[0].fireEvent('onmouseover');}";
    String onClickScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('click',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject){ arguments[0].fireEvent('onclick');}";
    ((JavascriptExecutor) BaseTestSetup.driver).executeScript(mouseOverScript,element);
    ((JavascriptExecutor) BaseTestSetup.driver).executeScript(onClickScript,element);
	}
	catch(Exception e){
		throw new Exception("Erro while triggering onclick for the element: "+element);
	}
}

public void clickPerform(By by) throws Exception {
    try {
        if (BaseTestSetup.driver.findElement(by).isDisplayed() && BaseTestSetup.driver.findElement(by).isEnabled()) {
            BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(by));
            clickWebelement(by);
        }
        else { 
            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].style.height='auto'; arguments[0].style.visibility='visible';", BaseTestSetup.driver.findElement(by));
            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].click();", BaseTestSetup.driver.findElement(by));  
        }
    }
    catch (Exception e) {
        throw new Exception("Error while clicking the element with identifier " + by + e.getMessage());
    }
}

public void clickWebelement(By locator) throws Exception {
    try {
    	((JavascriptExecutor) BaseTestSetup.driver).executeScript("window.scrollTo(0," + BaseTestSetup.driver.findElement(locator).getLocation().y + ")");
    	if(locator.toString().contains("tinymice")){
    		Actions actionsClick = new Actions(BaseTestSetup.driver);
            actionsClick.moveToElement(BaseTestSetup.driver.findElement(locator)).click(BaseTestSetup.driver.findElement(locator));        	
        }
    	else{
    		BaseTestSetup.driver.findElement(locator).sendKeys(Keys.CONTROL);
            BaseTestSetup.driver.findElement(locator).click();
    	}
        
    }
    catch (Exception e) {
        throw new Exception("Error while Clicking the webelement identified by " + locator + e.getMessage());
    }
}

public void compareByText(By by, String Actual){
	if(!(Actual).trim().isEmpty()){
		System.out.println(BaseTestSetup.driver.findElement(by).getText().trim());
		System.out.println(Actual);
	if(BaseTestSetup.driver.findElement(by).getText().equalsIgnoreCase(Actual)){
		System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(by).getText()+ ", The Actual Value : "+Actual + ". And it matches");
		}
		sleep(1000);}
	}

public int getWindowSize(){
	int iCount = 0;
	Set<String> currentWindows = driver.getWindowHandles();
	iCount = currentWindows.size();
	System.out.println(iCount);
	return iCount;
	
}

public void switchWindow(String windowTitle) throws Exception {

    BaseTestSetup.driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);

    Set<String> currentWindows = null;
    while (currentWindows == null || currentWindows.size() < 1) {
        currentWindows = BaseTestSetup.driver.getWindowHandles();
    }
   
    for (String window : currentWindows) {
        BaseTestSetup.driver.switchTo().window(window);
        System.out.println("Window title" + BaseTestSetup.driver.getTitle());
        if (BaseTestSetup.driver.getTitle().contains(windowTitle)) {
            break;
        }
    }
}

public void switchBackToParentWindow(String windowTitle) throws Exception {
    BaseTestSetup.driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
    Set<String> currentWindows = null;
    currentWindows = BaseTestSetup.driver.getWindowHandles();
    for (String window : currentWindows) {
        BaseTestSetup.driver.switchTo().window(window);
        if (BaseTestSetup.driver.getTitle().equalsIgnoreCase(windowTitle)) {
            break;
        }
    }
}

public void actionEnterData(By by, String data){
	if(!data.trim().isEmpty()){
	Actions actions = new Actions(driver);sleep(1500);
	WebElement ele1 = driver.findElement(by);	
	if(ele1.getText().trim()!=""){
		ele1.clear();
	}
	actions.moveToElement(ele1);
	actions.click();sleep(500);
	actions.sendKeys(data);
	actions.build().perform();sleep(500);
	}
}




public void actionMouseHover(By source ,By Destination ){
		Actions actions = new Actions(driver);
	sleep(1000);
	WebElement ele1 = driver.findElement(source);
	ele1.sendKeys("");
	actions.moveToElement(ele1).build().perform();sleep(2500);
	WebElement ele2 = driver.findElement(Destination);
	//ele2.sendKeys("");
	actions.moveToElement(ele2).click().perform();sleep(mediumWaitVal);
}

public void mouseOver(By by) {
    try {
        WebElement element = BaseTestSetup.driver.findElement(by);
        Actions action = new Actions(BaseTestSetup.driver);
        action.moveToElement(element);
       // action.sendKeys(Keys.ENTER).build().perform();
        action.moveToElement(element).click().build().perform();
       
    }
    catch (Exception e) {
    }
}

public void sub_menu(By main_menu,By sub_menu)
{
	try {
		Actions action=new Actions(BaseTestSetup.driver);
		WebElement mainMenu=BaseTestSetup.driver.findElement(main_menu);
		WebElement subMenu=BaseTestSetup.driver.findElement(sub_menu);
		action.moveToElement(mainMenu).build().perform();
		clickPerform(subMenu);
	} catch (Exception e) {
	}
}

public int getColumnNumber(String Headerlocator, String columnName) {
    int columnNumber = 1;
    for (WebElement element : BaseTestSetup.driver.findElements(By.xpath(Headerlocator))) {
        if (element.getText().trim().equals(columnName.trim()) || element.getAttribute("title").toString().trim().equals(columnName.trim())) {
            break;
        }
        else {
            columnNumber++;
        }
    }
    return columnNumber;
}

public int getColumnNumberAssignImg(String Headerlocator, String columnName) {
    int columnNumber = 1;
    String sTempValue = null ;
    if (columnName.equals("State")){
    	sTempValue = "alertsModel_statusState";
    }else if(columnName.equals("OwnerID")){
    	sTempValue = "jqgh_alertsModel_ownerInternalId";
    }    
    
    for (WebElement element : BaseTestSetup.driver.findElements(By.xpath(Headerlocator))) {
    	WebElement wle =  element.findElement(By.xpath("child::div"));
    	if(wle.getTagName().equals("div") && wle.getAttribute("id").equals(sTempValue)){
    		
    		break;    	
        
        }
        else {
            columnNumber++;
        }
    }
    return columnNumber;
}





public void clickPerform(WebElement element) throws Exception {
    try {
        if (element.isDisplayed()) {
            element.click();
        }
        else {
            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].style.height='auto'; arguments[0].style.visibility='visible';", element);
            ((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].click();", element);
        }
    }
    catch (Exception e) {
        throw new Exception("Error whiile clicking the element with locator:" + element + " :" + e.getMessage());
    }
} 
public void switchToWindow(){
	 String originalWindow =driver.getWindowHandle();
	 System.out.println(driver.getTitle());
 Set<String> chwin = driver.getWindowHandles();
 for (String win : chwin) {
     if (!originalWindow.equals(win)) {
         driver.switchTo().window(win);
         System.out.print("child window:" +win);
         System.out.println(driver.getTitle());
     }
 }
}

public void switchToParentWindow(){
	for(String winHandle : driver.getWindowHandles()){
	    driver.switchTo().window(winHandle);
	}
}

public void checkboxClick(By by, String data){
	if (!data.trim().isEmpty() && data.trim().equalsIgnoreCase("Yes")) {
		 actionClick(by);
	}
}
public void inputTextTab(By by, String data) {
	WebElement ele1 = driver.findElement(by);
	ele1.sendKeys("");sleep(250);
	ele1.clear();sleep(350);
	ele1.sendKeys(data);sleep(600);
	ele1.sendKeys(Keys.TAB);sleep(350);		
	}


public String getCurrentDate(){
	String pattern = "dd-MM-yyyy";
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

	String date = simpleDateFormat.format(new Date());
	System.out.println(date);
	return date;
	}


public void scrollToWebElement(By by){
    int bFlag = 0;
    bFlag = webElementExistance(by);
    if(bFlag == 1){
          JavascriptExecutor js = (JavascriptExecutor) BaseTestSetup.driver;
           js.executeScript("arguments[0].scrollIntoView()", BaseTestSetup.driver.findElement(by));
          screenshot();
    }
}


}


